import logging

from browser_use.telemetry.views import BaseTelemetryEvent
from browser_use.utils import singleton


logger = logging.getLogger(__name__)


@singleton
class ProductTelemetry:
	"""Lyra disables browser-use product telemetry at the bundled wheel boundary."""

	USER_ID_PATH = ""
	UNKNOWN_USER_ID = "UNKNOWN"
	_curr_user_id = UNKNOWN_USER_ID

	def __init__(self) -> None:
		self.debug_logging = False
		self._client = None
		logger.debug("Browser-use product telemetry disabled by Lyra bundle")

	def capture(self, event: BaseTelemetryEvent) -> None:
		return None

	def _direct_capture(self, event: BaseTelemetryEvent) -> None:
		return None

	def flush(self) -> None:
		return None

	@property
	def user_id(self) -> str:
		return self.UNKNOWN_USER_ID
